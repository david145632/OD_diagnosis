from django.urls import path

from App import views

urlpatterns = [
    path('diag01/', views.diag01, name='diag01'),
    path('diag01result', views.diag01_result, name='diag01result')
]
