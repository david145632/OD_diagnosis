from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.
def index(request):
    # return HttpResponse('加载成功!')
    return render(request, 'index.html', )


def diag01(request):
    return render(request, 'diagnose01.html', )


def diag01_result(request):
    name = request.POST.get('name')
    age = request.POST.get('age')
    gender = request.POST.get('gender')
    work_year = request.POST.get('work_year')
    pta1r_0 = request.POST.get('pta1r_0')
    pta1r_1 = request.POST.get('pta1r_1')
    pta1r_2 = request.POST.get('pta1r_2')
    pta1r_3 = request.POST.get('pta1r_3')
    pta1r_4 = request.POST.get('pta1r_4')
    pta1r_5 = request.POST.get('pta1r_5')
    pta1r = [int(pta1r_0), int(pta1r_1), int(pta1r_2), int(pta1r_3), int(pta1r_4), int(pta1r_5)]
    pta1l_0 = request.POST.get('pta1l_0')
    pta1l_1 = request.POST.get('pta1l_1')
    pta1l_2 = request.POST.get('pta1l_2')
    pta1l_3 = request.POST.get('pta1l_3')
    pta1l_4 = request.POST.get('pta1l_4')
    pta1l_5 = request.POST.get('pta1l_5')
    pta1l = [int(pta1l_0), int(pta1l_1), int(pta1l_2), int(pta1l_3), int(pta1l_4), int(pta1l_5)]
    pta2r_0 = request.POST.get('pta2r_0')
    pta2r_1 = request.POST.get('pta2r_1')
    pta2r_2 = request.POST.get('pta2r_2')
    pta2r_3 = request.POST.get('pta2r_3')
    pta2r_4 = request.POST.get('pta2r_4')
    pta2r_5 = request.POST.get('pta2r_5')
    pta2r = [int(pta2r_0), int(pta2r_1), int(pta2r_2), int(pta2r_3), int(pta2r_4), int(pta2r_5)]
    pta2l_0 = request.POST.get('pta2l_0')
    pta2l_1 = request.POST.get('pta2l_1')
    pta2l_2 = request.POST.get('pta2l_2')
    pta2l_3 = request.POST.get('pta2l_3')
    pta2l_4 = request.POST.get('pta2l_4')
    pta2l_5 = request.POST.get('pta2l_5')
    pta2l = [int(pta2l_0), int(pta2l_1), int(pta2l_2), int(pta2l_3), int(pta2l_4), int(pta2l_5)]
    pta3r_0 = request.POST.get('pta3r_0')
    pta3r_1 = request.POST.get('pta3r_1')
    pta3r_2 = request.POST.get('pta3r_2')
    pta3r_3 = request.POST.get('pta3r_3')
    pta3r_4 = request.POST.get('pta3r_4')
    pta3r_5 = request.POST.get('pta3r_5')
    pta3r = [int(pta3r_0), int(pta3r_1), int(pta3r_2), int(pta3r_3), int(pta3r_4), int(pta3r_5)]
    pta3l_0 = request.POST.get('pta3l_0')
    pta3l_1 = request.POST.get('pta3l_1')
    pta3l_2 = request.POST.get('pta3l_2')
    pta3l_3 = request.POST.get('pta3l_3')
    pta3l_4 = request.POST.get('pta3l_4')
    pta3l_5 = request.POST.get('pta3l_5')
    pta3l = [int(pta3l_0), int(pta3l_1), int(pta3l_2), int(pta3l_3), int(pta3l_4), int(pta3l_5)]

    print(name, age, gender, work_year, sep='\n')
    print(pta1r, pta1l, pta2r, pta2l, pta3r, pta3l, sep='\n')

    diagnosis = "重度噪声聋"
    disability = '五级伤残'
    context = {
        'diagnosis': diagnosis,
        'disability': disability,
    }
    return render(request, 'diag01result.html', context=context)
