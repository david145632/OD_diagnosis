from django.urls import path

from App import views

urlpatterns = [
    path('redirect/', views.redir, name='redirect'),
    path('diag01/', views.diag01, name='diag01'),
    path('diag01result', views.diag01_result, name='diag01result'),
    path('diag02/', views.diag02, name='diag02'),
    path('diag03/', views.diag03, name='diag03'),
    path('diag04/', views.diag04, name='diag04'),
    path('diag05/', views.diag05, name='diag05'),
]
