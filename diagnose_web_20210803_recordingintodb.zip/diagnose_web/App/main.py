import core_code
import pandas as pd

def main():
    # 输入 三次纯音测听结果 年龄 性别
    pta1r = [20, 25, 40, 45, 50, 60]
    pta1l = [20, 25, 40, 50, 75, 75]
    pta2r = [15, 25, 40, 45, 45, 65]
    pta2l = [25, 25, 40, 55, 75, 85]
    pta3r = [20, 25, 40, 50, 45, 55]
    pta3l = [25, 25, 35, 55, 70, 80]
    age = 38    # 18-80
    gender = 1  # 0：女 or 1：男
    # 输入有效性的检验  还应注意三次检查的时间间隔至少3天
    pta_table = [pta1r, pta1l, pta2r, pta2l, pta3r, pta3l]
    work_age = 5  # 工龄

    print('开始')
    # 读取校正矩阵
    adjust = pd.read_csv("corr.csv")
    # print('原始校正矩阵', adjust)
    global adjust_male, adjust_female
    adjust_male = adjust[['male500', 'male1000', 'male2000', 'male3000', 'male4000', 'male6000']]
    adjust_female = adjust[['female500', 'female1000', 'female2000', 'female3000', 'female4000', 'female6000']]

    result = core_code.diag_and_disa(pta_table=pta_table, age=age, gender=gender, work_age=work_age,
                                     adjust_female=adjust_female, adjust_male=adjust_male)
    '''
    返回结果是一个dict，keys包括'pta_after_adj', 'adjust_now', 'BHFTA', 'diagnosis', 'disability'
    可以用result['diagnosis']调取结果
    '''
    print('这里是输出结果：', result)
    print(result.keys())
    print(result['diagnosis'])
    print("end")


if __name__ == '__main__':
    main()
