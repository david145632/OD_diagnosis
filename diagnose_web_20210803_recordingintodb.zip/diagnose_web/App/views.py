import os
from django.http import HttpResponse
from django.shortcuts import render, redirect
from diagnose_web.settings import BASE_DIR
from . import core_code
import pandas as pd
from .models import UserInfo


def index(request):
    # return HttpResponse('加载成功!')
    return render(request, 'index.html', )


def diag01(request):
    return render(request, 'diagnose01.html', )


def diag01_result(request):
    name = request.POST.get('name')
    age = request.POST.get('age')
    gender = request.POST.get('gender')
    work_age = request.POST.get('work_year')
    pta1r_0 = request.POST.get('pta1r_0')
    pta1r_1 = request.POST.get('pta1r_1')
    pta1r_2 = request.POST.get('pta1r_2')
    pta1r_3 = request.POST.get('pta1r_3')
    pta1r_4 = request.POST.get('pta1r_4')
    pta1r_5 = request.POST.get('pta1r_5')
    pta1l_0 = request.POST.get('pta1l_0')
    pta1l_1 = request.POST.get('pta1l_1')
    pta1l_2 = request.POST.get('pta1l_2')
    pta1l_3 = request.POST.get('pta1l_3')
    pta1l_4 = request.POST.get('pta1l_4')
    pta1l_5 = request.POST.get('pta1l_5')
    pta2r_0 = request.POST.get('pta2r_0')
    pta2r_1 = request.POST.get('pta2r_1')
    pta2r_2 = request.POST.get('pta2r_2')
    pta2r_3 = request.POST.get('pta2r_3')
    pta2r_4 = request.POST.get('pta2r_4')
    pta2r_5 = request.POST.get('pta2r_5')
    pta2l_0 = request.POST.get('pta2l_0')
    pta2l_1 = request.POST.get('pta2l_1')
    pta2l_2 = request.POST.get('pta2l_2')
    pta2l_3 = request.POST.get('pta2l_3')
    pta2l_4 = request.POST.get('pta2l_4')
    pta2l_5 = request.POST.get('pta2l_5')
    pta3r_0 = request.POST.get('pta3r_0')
    pta3r_1 = request.POST.get('pta3r_1')
    pta3r_2 = request.POST.get('pta3r_2')
    pta3r_3 = request.POST.get('pta3r_3')
    pta3r_4 = request.POST.get('pta3r_4')
    pta3r_5 = request.POST.get('pta3r_5')
    pta3l_0 = request.POST.get('pta3l_0')
    pta3l_1 = request.POST.get('pta3l_1')
    pta3l_2 = request.POST.get('pta3l_2')
    pta3l_3 = request.POST.get('pta3l_3')
    pta3l_4 = request.POST.get('pta3l_4')
    pta3l_5 = request.POST.get('pta3l_5')
    title = "先生" if gender == "1" else "女士"
    pta1r = [int(pta1r_0), int(pta1r_1), int(pta1r_2), int(pta1r_3), int(pta1r_4), int(pta1r_5)]
    pta1l = [int(pta1l_0), int(pta1l_1), int(pta1l_2), int(pta1l_3), int(pta1l_4), int(pta1l_5)]
    pta2r = [int(pta2r_0), int(pta2r_1), int(pta2r_2), int(pta2r_3), int(pta2r_4), int(pta2r_5)]
    pta2l = [int(pta2l_0), int(pta2l_1), int(pta2l_2), int(pta2l_3), int(pta2l_4), int(pta2l_5)]
    pta3r = [int(pta3r_0), int(pta3r_1), int(pta3r_2), int(pta3r_3), int(pta3r_4), int(pta3r_5)]
    pta3l = [int(pta3l_0), int(pta3l_1), int(pta3l_2), int(pta3l_3), int(pta3l_4), int(pta3l_5)]
    pta_table = [pta1r, pta1l, pta2r, pta2l, pta3r, pta3l]
    # print(name, age, gender, work_year, sep='\n')
    # print(pta1r, pta1l, pta2r, pta2l, pta3r, pta3l, sep='\n')
    # print('开始')
    # 读取校正矩阵
    adjust = pd.read_csv(os.path.join(BASE_DIR, 'App', 'corr.csv'))
    # print('原始校正矩阵', adjust)
    adjust_male = adjust[['male500', 'male1000', 'male2000', 'male3000', 'male4000', 'male6000']]
    adjust_female = adjust[['female500', 'female1000', 'female2000', 'female3000', 'female4000', 'female6000']]

    result = core_code.diag_and_disa(pta_table=pta_table, age=age, gender=gender, work_age=work_age, adjust_female=adjust_female, adjust_male=adjust_male)
    '''
    返回结果是一个dict，keys包括'pta_after_adj', 'adjust_now', 'BHFTA', 'diagnosis', 'disability'
    可以用result['diagnosis']调取结果
    '''
    diagnosis = result['diagnosis']
    disability = result['disability']
    user_info = UserInfo()
    user_info.u_name = name
    user_info.u_age = age
    user_info.u_gender = gender
    user_info.work_year_more_than_3 = work_age
    user_info.right_ear_first_250 = pta1r_0
    user_info.right_ear_first_500 = pta1r_1
    user_info.right_ear_first_1000 = pta1r_2
    user_info.right_ear_first_2000 = pta1r_3
    user_info.right_ear_first_4000 = pta1r_4
    user_info.right_ear_first_8000 = pta1r_5
    user_info.left_ear_first_250 = pta1l_0
    user_info.left_ear_first_500 = pta1l_1
    user_info.left_ear_first_1000 = pta1l_2
    user_info.left_ear_first_2000 = pta1l_3
    user_info.left_ear_first_4000 = pta1l_4
    user_info.left_ear_first_8000 = pta1l_5
    user_info.right_ear_second_250 = pta2r_0
    user_info.right_ear_second_500 = pta2r_1
    user_info.right_ear_second_1000 = pta2r_2
    user_info.right_ear_second_2000 = pta2r_3
    user_info.right_ear_second_4000 = pta2r_4
    user_info.right_ear_second_8000 = pta2r_5
    user_info.left_ear_second_250 = pta2l_0
    user_info.left_ear_second_500 = pta2l_1
    user_info.left_ear_second_1000 = pta2l_2
    user_info.left_ear_second_2000 = pta2l_3
    user_info.left_ear_second_4000 = pta2l_4
    user_info.left_ear_second_8000 = pta2l_5
    user_info.right_ear_third_250 = pta3r_0
    user_info.right_ear_third_500 = pta3r_1
    user_info.right_ear_third_1000 = pta3r_2
    user_info.right_ear_third_2000 = pta3r_3
    user_info.right_ear_third_4000 = pta3r_4
    user_info.right_ear_third_8000 = pta3r_5
    user_info.left_ear_third_250 = pta3l_0
    user_info.left_ear_third_500 = pta3l_1
    user_info.left_ear_third_1000 = pta3l_2
    user_info.left_ear_third_2000 = pta3l_3
    user_info.left_ear_third_4000 = pta3l_4
    user_info.left_ear_third_8000 = pta3l_5
    user_info.u_diagnosis = diagnosis
    user_info.u_disability = disability
    user_info.save()
    print(result['pta_after_adj'])
    context = {
        'name': name,
        'title': title,
        'diagnosis': diagnosis,
        'disability': disability,
    }
    return render(request, 'diag01result.html', context=locals())


def diag02(request):
    return redirect("app:redirect")


def diag03(request):
    return redirect("app:redirect")


def diag04(request):
    return redirect("app:redirect")


def diag05(request):
    return redirect("app:redirect")


def redir(request):
    return render(request, "redirect.html")